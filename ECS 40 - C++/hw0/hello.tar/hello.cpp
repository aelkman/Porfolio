#include <iostream>
using namespace std;

int main() {

	cout << "Hello ECS40 from 56002" << endl;
	return 0;
}
